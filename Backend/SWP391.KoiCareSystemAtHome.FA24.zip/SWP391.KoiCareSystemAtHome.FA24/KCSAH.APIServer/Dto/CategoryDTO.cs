﻿namespace KCSAH.APIServer.Dto
{
    public class CategoryDTO
    {
        public string CategoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
